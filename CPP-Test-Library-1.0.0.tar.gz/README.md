A test library to support TDD in C++ projects
